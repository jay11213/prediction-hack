require("dotenv").config();

const express = require("express");
const cookieParser = require("cookie-parser");
const path = require("path");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = require("./src/db");
const { buildMockPrediction, evaluatePrediction, getCurrentPeriod } = require("./src/predictionEngine");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "development-only-secret";
const REQUIRE_TELEGRAM_INIT_DATA = process.env.REQUIRE_TELEGRAM_INIT_DATA === "true";

app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

function signUser(user) {
  return jwt.sign({ sub: user.id, userId: user.user_id }, JWT_SECRET, { expiresIn: "8h" });
}

function authRequired(req, res, next) {
  try {
    const token = req.cookies.session;
    if (!token) return res.status(401).json({ error: "Not authenticated" });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.getUserById(payload.sub);
    if (!user || !user.enabled) return res.status(401).json({ error: "Account disabled or unavailable" });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Session expired" });
  }
}

// Telegram initData validation based on Telegram's documented HMAC procedure.
function validateTelegramInitData(initData) {
  if (!initData) return false;
  if (!process.env.TELEGRAM_BOT_TOKEN) return false;

  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  if (!receivedHash) return false;
  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = crypto
    .createHmac("sha256", "WebAppData")
    .update(process.env.TELEGRAM_BOT_TOKEN)
    .digest();

  const calculatedHash = crypto
    .createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  return calculatedHash.length === receivedHash.length &&
    crypto.timingSafeEqual(Buffer.from(calculatedHash), Buffer.from(receivedHash));
}

app.post("/api/auth/login", async (req, res) => {
  const { userId, password, telegramInitData } = req.body || {};
  if (!userId || !password) return res.status(400).json({ error: "User ID and password are required" });

  if (REQUIRE_TELEGRAM_INIT_DATA && !validateTelegramInitData(telegramInitData)) {
    return res.status(403).json({ error: "Invalid Telegram session data" });
  }

  const user = db.getUserByUserId(String(userId).trim());
  if (!user || !user.enabled) return res.status(401).json({ error: "Invalid credentials or disabled account" });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: "Invalid credentials or disabled account" });

  res.cookie("session", signUser(user), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  });
  res.json({ ok: true, user: { userId: user.user_id, role: user.role } });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("session");
  res.json({ ok: true });
});

app.get("/api/me", authRequired, (req, res) => {
  res.json({ user: { userId: req.user.user_id, role: req.user.role } });
});

app.get("/api/dashboard", authRequired, (req, res) => {
  const currentPeriod = getCurrentPeriod();
  const prediction = db.getPrediction(currentPeriod) || (() => {
    const p = buildMockPrediction(currentPeriod);
    db.savePrediction(p);
    return p;
  })();

  // For the MVP, older periods receive deterministic mock actual results.
  db.evaluateExpiredPredictions(currentPeriod, evaluatePrediction);

  const history = db.getRecentPredictions(20).map(row => ({
    period: row.period,
    predictedType: row.predicted_type,
    predictedNumbers: [row.number_one, row.number_two],
    confidence: row.confidence,
    actualResult: row.actual_result,
    status: row.status
  }));

  const stats = db.getStats();
  const secondsIntoPeriod = Math.floor(Date.now() / 1000) % Number(process.env.PERIOD_LENGTH_SECONDS || 60);
  const countdown = Number(process.env.PERIOD_LENGTH_SECONDS || 60) - secondsIntoPeriod;

  res.json({
    demoMode: true,
    disclaimer: "Mock data only. This MVP does not predict real server-generated outcomes.",
    current: {
      period: currentPeriod,
      countdown,
      prediction: {
        type: prediction.predicted_type,
        numbers: [prediction.number_one, prediction.number_two],
        confidence: prediction.confidence,
        confirmation: "Pattern + contrarian demo signal"
      }
    },
    stats,
    history
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  db.initialize();
  console.log(`Telegram Prediction MVP running at http://localhost:${PORT}`);
});
