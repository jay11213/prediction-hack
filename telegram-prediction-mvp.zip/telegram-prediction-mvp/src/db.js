const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");

const dbFile = process.env.DB_FILE || "./data/app.sqlite";
const absoluteDbFile = path.resolve(dbFile);
fs.mkdirSync(path.dirname(absoluteDbFile), { recursive: true });
const sqlite = new Database(absoluteDbFile);

function initialize() {
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      enabled INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS predictions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      period TEXT UNIQUE NOT NULL,
      predicted_type TEXT NOT NULL,
      number_one INTEGER NOT NULL,
      number_two INTEGER NOT NULL,
      confidence INTEGER NOT NULL,
      actual_result INTEGER,
      status TEXT NOT NULL DEFAULT 'PENDING',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const existing = sqlite.prepare("SELECT id FROM users WHERE user_id = ?").get("demo_user");
  if (!existing) {
    const hash = bcrypt.hashSync("demo_pass", 12);
    sqlite.prepare("INSERT INTO users (user_id, password_hash, role) VALUES (?, ?, ?)")
      .run("demo_user", hash, "user");
  }
}

function getUserByUserId(userId) {
  return sqlite.prepare("SELECT * FROM users WHERE user_id = ?").get(userId);
}
function getUserById(id) {
  return sqlite.prepare("SELECT * FROM users WHERE id = ?").get(id);
}
function getPrediction(period) {
  return sqlite.prepare("SELECT * FROM predictions WHERE period = ?").get(String(period));
}
function savePrediction(p) {
  sqlite.prepare(`
    INSERT OR IGNORE INTO predictions
    (period, predicted_type, number_one, number_two, confidence, status)
    VALUES (?, ?, ?, ?, ?, 'PENDING')
  `).run(String(p.period), p.type, p.numbers[0], p.numbers[1], p.confidence);
}
function evaluateExpiredPredictions(currentPeriod, evaluator) {
  const rows = sqlite.prepare(`
    SELECT * FROM predictions
    WHERE status = 'PENDING' AND CAST(period AS INTEGER) < CAST(? AS INTEGER)
  `).all(String(currentPeriod));

  const update = sqlite.prepare(`
    UPDATE predictions SET actual_result = ?, status = ? WHERE period = ?
  `);
  const tx = sqlite.transaction(() => {
    for (const row of rows) {
      const actual = (Number(row.period) * 7 + 3) % 10; // deterministic mock result
      const status = evaluator(
        { type: row.predicted_type, numbers: [row.number_one, row.number_two] },
        actual
      );
      update.run(actual, status, row.period);
    }
  });
  tx();
}
function getRecentPredictions(limit) {
  return sqlite.prepare("SELECT * FROM predictions ORDER BY CAST(period AS INTEGER) DESC LIMIT ?").all(limit);
}
function getStats() {
  const evaluated = sqlite.prepare("SELECT * FROM predictions WHERE status != 'PENDING'").all();
  const wins = evaluated.filter(x => x.status === "WIN" || x.status === "JACKPOT").length;
  const jackpots = evaluated.filter(x => x.status === "JACKPOT").length;
  return {
    total: evaluated.length,
    wins,
    jackpots,
    winRate: evaluated.length ? Math.round((wins / evaluated.length) * 100) : 0
  };
}

module.exports = {
  initialize, getUserByUserId, getUserById, getPrediction, savePrediction,
  evaluateExpiredPredictions, getRecentPredictions, getStats
};
