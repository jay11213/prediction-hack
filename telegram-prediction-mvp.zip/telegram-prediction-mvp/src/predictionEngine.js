const PERIOD_LENGTH_SECONDS = Number(process.env.PERIOD_LENGTH_SECONDS || 60);

function getCurrentPeriod() {
  return String(Math.floor(Date.now() / 1000 / PERIOD_LENGTH_SECONDS));
}

// Replace this function later with a real, validated analytics/model pipeline.
// It intentionally returns deterministic mock values and must not be treated as a real predictor.
function buildMockPrediction(period) {
  const n = Number(period);
  const numberOne = (n * 3 + 1) % 10;
  const numberTwo = (n * 7 + 4) % 10;
  const type = ((numberOne + numberTwo) / 2) >= 5 ? "BIG" : "SMALL";
  const confidenceOptions = [80, 85, 90, 95];
  const confidence = confidenceOptions[n % confidenceOptions.length];

  return {
    period: String(period),
    type,
    numbers: [numberOne, numberTwo],
    confidence
  };
}

function evaluatePrediction(prediction, actual) {
  if (prediction.numbers.includes(actual)) return "JACKPOT";
  const actualType = actual >= 5 ? "BIG" : "SMALL";
  return prediction.type === actualType ? "WIN" : "LOSS";
}

module.exports = { getCurrentPeriod, buildMockPrediction, evaluatePrediction };
